﻿namespace _80_MVC_IdentityCustomize.Models.Enums
{
    public enum Status
    {
        Read, Continued, Planned
    }
}
